import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BusRoute } from '../Model/BusRoute';
import { Observable } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class SearchBusService {
  baseUrl = "http://localhost:8080/";

    
  constructor(private myHttp: HttpClient) { }

  findBusBySourceAndDestination(source:String,destination:String): Observable<BusRoute[]> {
    return this.myHttp.get<BusRoute[]>(this.baseUrl + "getBusRoutes/" + source+"/"+destination);
}

 
}
