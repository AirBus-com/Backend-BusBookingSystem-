import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { BusRoute } from '../Model/BusRoute';
import { ReservationDto } from '../Model/ReservationDto';
import { ReservationService } from '../selectseat/reservation.service';
import { SearchBusService } from './search-bus.service';


@Component({
  selector: 'app-searchbus',
  templateUrl: './searchbus.component.html',
  styleUrls: ['./searchbus.component.css']
})
export class SearchbusComponent implements OnInit {

  myres: ReservationDto = new ReservationDto();
  public tempSearchBus: BusRoute[] | undefined;
  constructor(private sbs:SearchBusService,private myHttp:HttpClient,private abs:ReservationService) { }
  ngOnInit(): void {
  }


  source: any ;
  destination: any ;

  findBusRouteBySourceAndDestination(source:string,destination:string){
    this.sbs.findBusBySourceAndDestination(source,destination).subscribe((data:BusRoute[])=>{
    if(data!=null){
        this.tempSearchBus=data;
        console.log(this.tempSearchBus);
        console.log(data)
      //  sessionStorage.setItem("busRouteDetails",JSON.stringify(data)); // storing this on browser session
    }
    else{
        alert("unable to fetch");
    }})
 }


 addReservation(res: ReservationDto){
  this.abs.addReservation(res).subscribe((data)=>{
    if(data!=null){
      res.ticketStatus="CONFIRM";
    
      alert("adding is successful");
      

    }},
    (err)=>{
      alert("some thing went wrong");
      console.log(err);
    }
  
  )

}

}
