import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchbusComponent } from './searchbus/searchbus.component';
import { HomeComponent } from './home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SelectseatComponent } from './selectseat/selectseat.component';

import { ReservationComponent } from './reservation/reservation.component';
import { ViewTicketComponent } from './view-ticket/view-ticket.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { SeatsComponent } from './seats/seats.component';



@NgModule({
  declarations: [
    AppComponent,
    SearchbusComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    SelectseatComponent,
   
    ReservationComponent,
        ViewTicketComponent,
        CancelTicketComponent,
        SeatsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
