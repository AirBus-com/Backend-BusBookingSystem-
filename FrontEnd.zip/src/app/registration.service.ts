import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Registration } from './Model/Registration';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  myreg : Registration = new Registration;

  constructor(private myHttp: HttpClient) { }

  ngOnInit()   {
      //this.reg = new Registration();
      
  }
  
  findRegistrationService(email: String): Observable<Registration> {
    return this.myHttp.get<Registration>("http://localhost:8080/getreg/"+email);
  }
  addRegistrationService(reg: Registration)  {
    return this.myHttp.post("http://localhost:8080/addreg",reg,{responseType:'text'});
  }
  
  modifyRegistrationService(reg: Registration)  {
    return this.myHttp.put("http://localhost:8080/modifyreg",reg,{responseType:'text'});
  }
  deleteRegistrationService(reg: Registration)  {
    return this.myHttp.delete("http://localhost:8080/deletereg/"+reg.email,{responseType:'text'});
  }

  
  userAuthenticationService(user:Registration): Observable<Registration>
  {
    return this.myHttp.post<Registration>("http://localhost:8080/login",user);
  }

}
