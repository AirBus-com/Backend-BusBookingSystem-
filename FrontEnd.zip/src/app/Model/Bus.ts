import { BusRoute } from "./BusRoute";
export class Bus{
     busNumber: number |undefined;
     facility :string | undefined;
     status:string |undefined;
     busSet: BusRoute[]|undefined;
}