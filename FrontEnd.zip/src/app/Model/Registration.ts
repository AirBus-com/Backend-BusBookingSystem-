export class Registration {
    email:String |undefined;    
    firstName:String |undefined;
    middleName: String |undefined;        
    lastName: String |undefined;    
    gender: String |undefined;
    password: String |undefined;    
    phone: number |undefined;
}
export class userValidate
{
   email:string |undefined;  
   password:string |undefined;
}