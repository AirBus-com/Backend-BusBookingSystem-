export class ReservationDto{
    ticketNumber: number|undefined;
    bookingDate: Date| undefined;
    journeyDate: Date|undefined;
    seatNumber: number|undefined;
    ticketStatus:string|undefined;
    reschduledDate: Date|undefined;
    refund:number|undefined;
    cancellationDate: Date|undefined;
    transactionId:number|undefined;
    routeNumber :number|undefined;
    }
    