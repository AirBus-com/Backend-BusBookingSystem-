//import { Reservation } from "./Reservation";

import { Reservation } from "./Reservation";

export class BusRoute{
    routeNumber: number| undefined;
    destination:string |undefined;
    distance: number| undefined;
    endTime:string|undefined;
    facility: string|undefined;
    fare:number|undefined;
    source: string|undefined;
    startTime:string|undefined;
    resSet: Reservation[]|undefined;
    }