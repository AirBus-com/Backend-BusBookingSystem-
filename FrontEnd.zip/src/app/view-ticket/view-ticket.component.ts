import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Reservation } from '../Model/Reservation';
import { ReservationService } from '../selectseat/reservation.service';

@Component({
  selector: 'app-view-ticket',
  templateUrl: './view-ticket.component.html',
  styleUrls: ['./view-ticket.component.css']
})
export class ViewTicketComponent implements OnInit {
 
  isShowDiv = false;
  tno=0
  constructor(private sbs:ReservationService,private myHttp:HttpClient) { }

  hideMeTicket() {
    this.isShowDiv = !this.isShowDiv;
  }
  ngOnInit(): void {
  }

  tempfindReservation: Reservation=new Reservation();
  findReservation(tno:number){
    this.sbs.findReservationService(tno).subscribe((data)=>{
    if(data!=null){
        this.tempfindReservation=data;
        console.log(this.tempfindReservation);
        console.log(data);
      // 
        
       // storing this on browser session
    }
    else{
        alert("unable to fetch");
    }})

 }



 
 
  

}
