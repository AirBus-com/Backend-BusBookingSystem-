import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { BusRoute } from '../Model/BusRoute';
import { SearchBusService } from '../searchbus/search-bus.service';
import { Router, ActivatedRoute } from '@angular/router'; 
declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  sourceSample = ['BANGALORE',  'HYDERABAD', 'TIRUPATI'];
;
  destSample = this.sourceSample;

  constructor(private sbs:SearchBusService,private myHttp:HttpClient,private router:Router) { }
  searchDetails = {
    source: 'BANGALORE',
    dest: 'HYDERABAD',
    date: (new Date()).toISOString().substring(0, 10),
  }
  
  busNum:number|undefined;
  ngOnInit(): void {
   

  }

  onSubmit() {
    //console.log(this.searchDetails)
    this.router.navigate(['selectseat']);

  }

    

  source: any ;
  destination: any ;
  tempSearchBus: BusRoute[] | undefined;
  findBusRouteBySourceAndDestination(source:string,destination:string){
    this.sbs.findBusBySourceAndDestination(source,destination).subscribe((data:BusRoute[])=>{
    if(data!=null){
        this.tempSearchBus=data;
        console.log(this.tempSearchBus);
        console.log(data);
      // 
        
       // storing this on browser session
    }
    else{
        alert("unable to fetch");
    }})

 }

 sendRouteNumber(mySearch: BusRoute)
 {
   alert(mySearch.routeNumber);
   sessionStorage.setItem("selectedRouteNumber",JSON.stringify(mySearch));
   this.router.navigate(['selectseat']);
 }

}
