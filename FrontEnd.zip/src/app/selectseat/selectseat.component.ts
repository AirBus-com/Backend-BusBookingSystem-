import { Component, OnInit } from '@angular/core';
import { BusRoute } from '../Model/BusRoute';
import { Router, ActivatedRoute } from '@angular/router'; 
import { HttpClient } from '@angular/common/http';
import { ReservationService } from './reservation.service';
import { ReservationDto } from '../Model/ReservationDto';
import { SearchBusService } from '../searchbus/search-bus.service';
import { R3NgModuleMetadata } from '@angular/compiler';
import { Reservation } from '../Model/Reservation';
import { find } from 'rxjs/operators';

declare var jQuery: any;
declare var $: any;



function seatSelectionByNumber()
{
  $("button").click(function() {
    alert(jQuery.id);
    
  });
  return Number(jQuery.id);
}
function hello() {
  alert('welcome to seat selection!!!');
 

}
@Component({
  selector: 'app-selectseat',
  template: `
    <button (click)="onClick($event)" id="test">Click</button>`,
  templateUrl: './selectseat.component.html',
  styleUrls: ['./selectseat.component.css']
})

export class SelectseatComponent implements OnInit {
  router: any;
  isShowDiv = false;
  
  
  constructor(private sbs:ReservationService,private myHttp:HttpClient) { 

  }
  tempAry:Array<BusRoute>=[];
  str:any|undefined;
  public  sendingTicketNum=0
  seatNum :Number|undefined;  seat:any
  
  viewSeatAvailability() {
    this.isShowDiv = !this.isShowDiv;
  }


  seatSample = ['2','4','17','30','3','23'];

  public  mySelectedRoute: BusRoute|undefined;
  myres: ReservationDto = new ReservationDto()
  reservationHandle:Reservation =new Reservation();
   ngOnInit(): void {

  this.data = sessionStorage.getItem("selectedRouteNumber");
   let  mySelectedRoute: BusRoute = JSON.parse(this.data);
   this.mySelectedRoute=JSON.parse(this.data);
   alert('welcome'+mySelectedRoute.routeNumber);
   //console.log("this is my selected route"+mySelectedRoute.routeNumber);
   //this.giveMeRouteNumber(mySelectedRoute.routeNumber);
    hello();
    
   }

   select()
   {
     
   }
   seatButtonNumber :number|undefined
   onSubmit(event: { target: any; srcElement: any; currentTarget: any; })
   {
    var target = event.target || event.srcElement || event.currentTarget;
    var idAttr = target.attributes.id;
    this.seatButtonNumber = idAttr.nodeValue;
   }

   counterValue: number =Math.floor((Math.random() * 1000)+89);
   date :Date | undefined
   data: any | undefined;
   
   addReservation(res: ReservationDto){

    res.routeNumber=this.mySelectedRoute?.routeNumber;
    
     const str1=res.routeNumber;
     var null_date = new Date(0);
    res.ticketStatus="CONFIRM";
    res.ticketNumber=this.counterValue+1;
    this.counterValue=res.ticketNumber;
    this.sendingTicketNum=res.ticketNumber
    res.transactionId=Math.floor((Math.random() * 100) + 1);
    res.cancellationDate=null_date;
   
    alert('your ticket number is :'+this.counterValue);
    
   //this.router.navigate(['selectseat']);
    
    this.sbs.addReservation(res).subscribe((data)=>{
  
      if(data!=null){

      
        alert(" payment done !!!! you have successfully booked a ticket !!!");
       

      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )

      
  }

 




  


 //------------------------------seat selection--------------//


}
