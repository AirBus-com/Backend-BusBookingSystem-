import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reservation } from '../Model/Reservation';
import { ReservationDto } from '../Model/ReservationDto';


@Injectable({
  providedIn: 'root'
})
export class ReservationService {

  baseUrl = "http://localhost:8080/";

    
  constructor(private myHttp: HttpClient) { }

  addReservation(res: ReservationDto)  {
    return this.myHttp.post("http://localhost:8080/addReservation",res,{responseType:'text'});
}
findReservationService(tno:Number): Observable<Reservation> {
  return this.myHttp.get<Reservation>("http://localhost:8080/getReservation/"+tno);
}

modifyReservationService(reserv:Reservation)  {
  return this.myHttp.put("http://localhost:8080/modifyReservation",reserv,{responseType:'text'});
   
}

}
