import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Reservation } from '../Model/Reservation';
import { ReservationService } from '../selectseat/reservation.service';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {

  constructor(private sbs:ReservationService,private myHttp:HttpClient)
  {}

  ngOnInit(): void {
  }

  reserv:Reservation =new Reservation()
 modifyReservation(reserv:Reservation){


  this.sbs.modifyReservationService(reserv).subscribe((data)=>{
    if(data!=null){
      reserv.ticketStatus='CANCELLED';
      reserv.cancellationDate;
      reserv.refund=500;
      console.log(data);
      alert("Ticket cancelled ");
      
    }},
    (err)=>{
      alert("some thing went wrong");
      console.log(err);
    }
  
  )

}

}
