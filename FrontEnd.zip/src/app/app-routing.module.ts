import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ReservationComponent } from './reservation/reservation.component';
import { SearchbusComponent } from './searchbus/searchbus.component';
import { SeatsComponent } from './seats/seats.component';
import { SelectseatComponent } from './selectseat/selectseat.component';
import { SignupComponent } from './signup/signup.component';
import { ViewTicketComponent } from './view-ticket/view-ticket.component';

const routes: Routes = [
  // { path:'',redirectTo:"/home",pathMatch:'full'},
  { path:"home",component:HomeComponent },
  { path:"login",component: LoginComponent},
  { path:"signup",component:SignupComponent },
  { path:"searchbus",component:SearchbusComponent },
  { path:"selectseat",component:SelectseatComponent },
  { path:"reservation",component:ReservationComponent },
  { path:"viewticket",component:ViewTicketComponent },
  { path:"cancelticket",component:CancelTicketComponent },
  { path:"seat",component:SeatsComponent },
  // { path:"settings",component:SettingsComponent,
  //   children:[
  //     { path:'',redirectTo:"profile",pathMatch:'full'},
  //     { path:"profile",component:SettingsProfileComponent },
  //     { path:"contact",component:SettingsContactComponent },
  //     { path:"**",component:PageNotFoundComponent }    
  //   ]
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
