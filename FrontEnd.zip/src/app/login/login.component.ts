import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Registration } from '../Model/Registration';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router,private lss:RegistrationService) { }

  ngOnInit(): void {
  }

  tempUser: Registration =new Registration();
  userAuthentication()
  {
    this.lss.userAuthenticationService(this.tempUser).subscribe((data: Registration)=>
    {
      if(data!=null)
      {
        this.tempUser=data;
        console.log(data);
        this.router.navigate(['/home']);
        alert('Login Successful')
      }
      else
      {
        alert('User NotFound');
      }
    })
  }
  
}
