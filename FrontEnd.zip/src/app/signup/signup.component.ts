import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Registration } from '../Model/Registration';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  myreg : Registration = new Registration;

  constructor(private cs: RegistrationService,
                   private myhttp:HttpClient,private router:Router) { }

  ngOnInit()   {
      //this.reg = new Registration();
      
  }
  
  addRegistrationService(reg:Registration){
    this.cs.addRegistrationService(reg).subscribe((data)=>{
      if(data != null) {
        
        alert("Registration is successful");
        this.router.navigate(['login']);
        
    }
 }, (err) => {
    alert("something went wrong");
    console.log(err);
 })
}

}
