package com.airbus.service;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.airbus.pojos.Registration;
import com.airbus.pojos.UnAuthorizedTicket;
import com.airbus.repos.RegistrationRepository;
import com.airbus.service.exception.RegistrationNotFoundException;
@Repository
public class UnauthorizedTicketServiceImpl implements UnauthorizedTicketService {
	@PersistenceContext

	EntityManager entityManager;
	
	@Autowired
	RegistrationRepository  regRepo;
	
	@Transactional
	public void addUnauthorizedTicket(UnAuthorizedTicket unauth) {
		// TODO Auto-generated method stub
		entityManager.persist(unauth);
	}

	@Transactional
	public UnAuthorizedTicket findUnauthorizedTicket(Integer id) {
		// TODO Auto-generated method stub
		return entityManager.find(UnAuthorizedTicket.class,id);
	}
@SuppressWarnings({ "unchecked", "rawtypes" })
	
	@Transactional
	public Set<UnAuthorizedTicket> findUnauthorizedTickets() {
		Set<UnAuthorizedTicket> UnauthTickSet;
		 Query query = entityManager.createQuery("from UnauthorizedTicket");
			
			UnauthTickSet = new HashSet(query.getResultList());
	         
		        
			    return UnauthTickSet;
	}
	

	@Transactional
	public void modifyUnauthorizedTicket(UnAuthorizedTicket unauth) {
		// TODO Auto-generated method stub
		entityManager.merge(unauth);
	}

	
	

	@Transactional
	public void removeUnauthorzsedTicket(Integer id) {
		// TODO Auto-generated method stub
		UnAuthorizedTicket aTemp = entityManager.find(UnAuthorizedTicket.class,id);
		entityManager.remove(aTemp);
	}
	
	
	

}