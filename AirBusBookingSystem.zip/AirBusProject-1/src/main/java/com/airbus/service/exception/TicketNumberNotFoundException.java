package com.airbus.service.exception;

public class TicketNumberNotFoundException extends Exception {

	public TicketNumberNotFoundException(String message) {
		super(message);

	}

}
