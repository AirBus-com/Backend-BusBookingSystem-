package com.airbus.service;


import java.time.LocalDate;
import java.util.Set;
import org.springframework.stereotype.Service;

import com.airbus.pojos.BusRoute;
import com.airbus.service.exception.BusRouteAlreadyExistsException;
import com.airbus.service.exception.BusRouteNotFoundException;


@Service
public interface BusRouteService {
	
	String addBusRouteService(BusRoute bRou) throws BusRouteAlreadyExistsException;
	BusRoute findBusRouteService(Integer rno) throws BusRouteNotFoundException;
	Set<BusRoute> findBusRoutesService();
	Set<BusRoute> busSearchService(String Source, String Destination) throws BusRouteNotFoundException ;
	String modifyBusRouteService(BusRoute bRou) throws BusRouteNotFoundException;
	String removeBusRouteService(Integer rno) throws BusRouteNotFoundException;
	//Set<BusRoute>busSearchService(String Source,String Destination,LocalDate JourneyDate);
}
