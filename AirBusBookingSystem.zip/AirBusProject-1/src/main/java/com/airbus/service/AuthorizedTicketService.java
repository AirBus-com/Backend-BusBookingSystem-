package com.airbus.service;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.airbus.pojos.AuthorizedTicket;
import com.airbus.service.exception.AuthorizedTicketAlreadyExistsException;
import com.airbus.service.exception.AuthorizedTicketNotFoundException;




@Service
public interface AuthorizedTicketService {

	String addAuthorizedTicketService(AuthorizedTicket aRef) throws AuthorizedTicketAlreadyExistsException;   	//C - add/create
	AuthorizedTicket findAuthorizedTicketService(Integer id);     //R - find/reading
	Set<AuthorizedTicket> findAuthorizedTicketsService();     		//R - find all/reading all
	String modifyAuthorizedTicketService(AuthorizedTicket aRef) throws AuthorizedTicketNotFoundException; 	//U - modify/update
	String removeAuthorizedTicketService(Integer id) throws AuthorizedTicketNotFoundException;		 //D - remove/delete
	
	
}