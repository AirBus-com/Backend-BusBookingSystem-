package com.airbus.service.exception;

public class AuthorizedTicketNotFoundException extends Exception {

	public AuthorizedTicketNotFoundException(String message) {
		super(message);

	}

}
