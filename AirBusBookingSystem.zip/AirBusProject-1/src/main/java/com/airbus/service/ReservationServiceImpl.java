package com.airbus.service;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airbus.dtos.ReservationDto;
import com.airbus.pojos.BusRoute;
import com.airbus.pojos.Reservation;
import com.airbus.repos.BusRouteRepository;
import com.airbus.repos.ReservationRepository;
import com.airbus.service.exception.TicketNumberAlreadyExistsException;
import com.airbus.service.exception.TicketNumberNotFoundException;

@Service
public class ReservationServiceImpl implements ReservationService{

	@Autowired
	ReservationRepository rsRepo;
	@Autowired
	BusRouteRepository brRepo;
	
	@Override
	public String addReservationService(ReservationDto rsRef) throws TicketNumberAlreadyExistsException{
		// TODO Auto-generated method stub
		Reservation r = new Reservation();
		BusRoute busRoute = brRepo.findBusRoute(rsRef.getRouteNumber());
		busRoute.getResvSet().add(r);
		r.setRoute(busRoute);
		r.setCancellationDate(rsRef.getCancellationDate());
		r.setTicketNumber(rsRef.getTicketNumber());
		r.setBookingDate(rsRef.getBookingDate());
		r.setJourneyDate(rsRef.getJourneyDate());
		r.setSeatNumber(rsRef.getSeatNumber());
		r.setTicketStatus(rsRef.getTicketStatus());
		r.setRefund(rsRef.getRefund());
		r.setRescheduledDate(rsRef.getRescheduledDate());
		r.setTransactionId(rsRef.getTransactionId());
		brRepo.modifyBusRoute(busRoute);
		
		return "Reservation added successfully";
	}

	@Override
	public Reservation findReservationService(Integer ticketno) throws TicketNumberNotFoundException {
		// TODO Auto-generated method stub
		return rsRepo.findReservation(ticketno);
	}

	@Override
	public Set<Reservation> findReservationsService() {
		// TODO Auto-generated method stub
		return rsRepo.findReservations();
	}

	@Override
	public String modifyReservationService(Reservation rsRef) throws TicketNumberNotFoundException {
		// TODO Auto-generated method stub
		Reservation r =rsRepo.findReservation(rsRef.getTicketNumber());
		if(r!=null)
		{
		rsRepo.modifyReservation(rsRef);
		}
		else {
			throw new TicketNumberNotFoundException("Ticket Number Not Found");
		}
		return "Reservation modified successfully";
	}

	@Override
	public String removeReservationService(Integer ticketno) throws TicketNumberNotFoundException {
		// TODO Auto-generated method stub
		
		Reservation r =rsRepo.findReservation(ticketno);
		if(r!=null)
		{
		rsRepo.removeReservation(r.getTicketNumber());
		}
		else {
			throw new TicketNumberNotFoundException("Ticket Number Not Found");
		}
		return "Reservation Deleted successfully";
	}
	
	@Override
	public Set<Reservation> cancelledTicketsService() throws TicketNumberAlreadyExistsException {

		return rsRepo.cancelledTicketSearch();
	}
	@Override
	public String cancellationTicketByTicketNumberService(Integer tno) throws TicketNumberNotFoundException {
		// TODO Auto-generated method stub
		try {
			rsRepo.cancellationTicketByTicketNumber(tno);
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				throw new TicketNumberNotFoundException("Ticket Number Not Found");
			}
		return "Reservation canecelled successfully";
		}
}