package com.airbus.service.exception;


public class BusRouteAlreadyExistsException extends Exception {

	public BusRouteAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
