package com.airbus.service.exception;


public class TicketNumberAlreadyExistsException extends Exception {

	public TicketNumberAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
