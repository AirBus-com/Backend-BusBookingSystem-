package com.airbus.service;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.airbus.pojos.Registration;
import com.airbus.service.exception.RegistrationAlreadyExistsException;
import com.airbus.service.exception.RegistrationNotFoundException;


@Service
public interface RegistrationService {
	String addRegistrationService(Registration reg) throws RegistrationAlreadyExistsException;
	Registration findRegistrationService(String email) throws RegistrationNotFoundException ;     
	Set<Registration> findRegistrationsService();     		
	String modifyRegistrationService(Registration reg) throws RegistrationNotFoundException ; 	
	String removeRegistrationService(String email) throws RegistrationNotFoundException ;		
	Registration userAuthenticationService(String userEmail,String userPassword) throws RegistrationNotFoundException;
}