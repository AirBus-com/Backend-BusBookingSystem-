package com.airbus.service.exception;


public class AuthorizedTicketAlreadyExistsException extends Exception {

	public AuthorizedTicketAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
