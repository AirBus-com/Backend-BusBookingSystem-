package com.airbus.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airbus.pojos.AuthorizedTicket;
import com.airbus.repos.AuthorizedTicketRepository;
import com.airbus.service.exception.AuthorizedTicketAlreadyExistsException;
import com.airbus.service.exception.AuthorizedTicketNotFoundException;




@Service
public class AuthorizedTicketServiceImpl implements AuthorizedTicketService{

	@Autowired
	AuthorizedTicketRepository authRepo;

	@Override
	public String addAuthorizedTicketService(AuthorizedTicket aRef) throws AuthorizedTicketAlreadyExistsException {
		try {
			authRepo.addAuthorizedTicket(aRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AuthorizedTicketAlreadyExistsException("AuthorizedTicket already exists");
			
		}
		return "AuthorizedTicket added successfully";
	}

	
	@Override
	public AuthorizedTicket findAuthorizedTicketService(Integer id) {
		// TODO Auto-generated method stub
		return authRepo.findAuthorizedTicket(id);
	}

	@Override
	public Set<AuthorizedTicket> findAuthorizedTicketsService() {
		// TODO Auto-generated method stub
		return authRepo.findAuthorizedTickets();
	}

	@Override
	public String  modifyAuthorizedTicketService(AuthorizedTicket aRef) throws AuthorizedTicketNotFoundException {
		AuthorizedTicket auth =authRepo.findAuthorizedTicket(aRef.getId());
		if(auth!=null)
		{authRepo.modifyAuthorizedTicket(aRef);}
		else {
			throw new AuthorizedTicketNotFoundException("AuthorizedTicket Not Found");
		}
	 
	return "AuthorizedTicket modified successfully";
	}


	@Override
	public String removeAuthorizedTicketService(Integer id) throws AuthorizedTicketNotFoundException {
		AuthorizedTicket auth =authRepo.findAuthorizedTicket(id);
		if(auth!=null)
		{authRepo.removeAuthorizedTicket(auth.getId());}
		else {
			throw new AuthorizedTicketNotFoundException("AuthorizedTicket Not Found");
		}
		return "AuthorizedTicket Deleted successfully";
	}

}
