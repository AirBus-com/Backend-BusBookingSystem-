package com.airbus.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.airbus.dtos.ReservationDto;
import com.airbus.pojos.Reservation;
import com.airbus.service.exception.TicketNumberAlreadyExistsException;
import com.airbus.service.exception.TicketNumberNotFoundException;

@Service
public interface ReservationService{
	String addReservationService(ReservationDto rsRef) throws TicketNumberAlreadyExistsException;   	//C - add/create
	Reservation findReservationService(Integer ticketno) throws TicketNumberNotFoundException;     //R - find/reading
	Set<Reservation> findReservationsService();     		//R - find all/reading all
	String modifyReservationService(Reservation rsRef) throws TicketNumberNotFoundException; 	//U - modify/update
	String removeReservationService(Integer ticketno) throws TicketNumberNotFoundException;		 //D - remove/delete
	Set<Reservation> cancelledTicketsService() throws TicketNumberAlreadyExistsException;
	String cancellationTicketByTicketNumberService(Integer tno) throws TicketNumberNotFoundException ;
}