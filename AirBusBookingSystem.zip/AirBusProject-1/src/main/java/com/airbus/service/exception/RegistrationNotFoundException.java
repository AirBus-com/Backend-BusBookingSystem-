package com.airbus.service.exception;

public class RegistrationNotFoundException extends Exception {

	public RegistrationNotFoundException(String message) {
		super(message);

	}

}
