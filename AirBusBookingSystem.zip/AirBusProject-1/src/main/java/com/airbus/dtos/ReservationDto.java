package com.airbus.dtos;

import java.time.LocalDate;

public class ReservationDto {

	private Integer ticketNumber;
	
	private LocalDate bookingDate=LocalDate.now();
	
	private LocalDate journeyDate=LocalDate.now();
	
	private Integer seatNumber;
	
	private String ticketStatus;
	
	private LocalDate cancellationDate=LocalDate.now();
	
	private LocalDate rescheduledDate =LocalDate.now();
	
	private Integer refund;
	
	private Integer transactionId;

	private Integer routeNumber;

	public ReservationDto() {
		System.out.println("Reservation Dto called..");
	}
	public Integer getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(Integer ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public LocalDate getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(LocalDate journeyDate) {
		this.journeyDate = journeyDate;
	}

	public Integer getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(Integer seatNumber) {
		this.seatNumber = seatNumber;
	}

	public String getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public LocalDate getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(LocalDate cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public LocalDate getRescheduledDate() {
		return rescheduledDate;
	}

	public void setRescheduledDate(LocalDate rescheduledDate) {
		this.rescheduledDate = rescheduledDate;
	}

	public Integer getRefund() {
		return refund;
	}

	public void setRefund(Integer refund) {
		this.refund = refund;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getRouteNumber() {
		return routeNumber;
	}

	public void setRouteNumber(Integer routeNumber) {
		this.routeNumber = routeNumber;
	}
	
	
}