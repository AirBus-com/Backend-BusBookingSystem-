package com.airbus.pojos;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the AUTHORIZEDTICKET database table.
 * 
 */
@Entity
@Table(name="authorizedticket")
public class AuthorizedTicket {
	@Id
	//@GeneratedValue
	@Column(name="ID")
	private Integer id;
	
	
	@ManyToOne
	@JoinColumn(name="EMAIL")
	private Registration registration;

	//bi-directional one-to-one association to Reservation
	@ManyToOne
	@JoinColumn(name="TICKETNUMBER")
	private Reservation reservation;

	public AuthorizedTicket() {
		super();
		System.out.println("Authorized ticket is called");
	}

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@JsonIgnore
	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}

	@JsonIgnore
	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	

}