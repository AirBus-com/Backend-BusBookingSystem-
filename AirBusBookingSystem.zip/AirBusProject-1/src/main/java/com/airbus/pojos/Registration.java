package com.airbus.pojos;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the REGISTRATION database table.
 * 
 */
@Entity
@Table(name="registration")
public class Registration {

	@Id
	//@GeneratedValue
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="FIRSTNAME")
	private String firstName;
	
	@Column(name="GENDER")
	private String gender;
	
	@Column(name="LASTNAME")
	private String lastName;
	
	@Column(name="MIDDLENAME")
	private String middleName;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="PHONE")
	private Long phone;

//	//bi-directional many-to-one association to AuthorizedTicket
	@OneToMany(mappedBy="registration", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	Set<AuthorizedTicket> authSet= new HashSet<AuthorizedTicket>();
	
	public Registration() {
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPhone() {
		return this.phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	@JsonIgnore
	public Set<AuthorizedTicket> getAuthSet() {
		return authSet;
	}

	public void setAuthSet(Set<AuthorizedTicket> authSet) {
		this.authSet = authSet;
	}

}