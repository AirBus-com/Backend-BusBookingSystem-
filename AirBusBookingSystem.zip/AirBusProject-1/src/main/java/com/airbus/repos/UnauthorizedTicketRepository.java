package com.airbus.repos;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.airbus.pojos.UnAuthorizedTicket;
@Repository
public interface UnauthorizedTicketRepository {
	
	void addUnauthorizedTicket( UnAuthorizedTicket unauth);
	 UnAuthorizedTicket findUnauthorizedTicket(Integer id);
	Set< UnAuthorizedTicket> findUnauthorizedTickets();
	void modifyUnauthorizedTicket( UnAuthorizedTicket unauth);
	void removeUnauthorzsedTicket(Integer id);
}