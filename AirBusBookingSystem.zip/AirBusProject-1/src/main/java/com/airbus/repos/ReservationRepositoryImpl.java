package com.airbus.repos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.airbus.pojos.Reservation;


@Repository
public class ReservationRepositoryImpl implements ReservationRepository {
	@PersistenceContext
	EntityManager entityManager;
	@Transactional
	public void addReservation(Reservation reserv) {
		// TODO Auto-generated method stub
		entityManager.persist(reserv);
	}

	@Transactional
	public Reservation findReservation(Integer tno) {
		// TODO Auto-generated method stub
		return entityManager.find(Reservation.class,tno);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Reservation> findReservations() {
		// TODO Auto-generated method stub
		Set<Reservation> reservSet;
		 Query query = entityManager.createQuery("from Reservation");
		
		reservSet = new HashSet(query.getResultList());
         
	        
		    return reservSet;
	}

	@Transactional
	public void modifyReservation(Reservation reserv) {
		// TODO Auto-generated method stub
		entityManager.merge(reserv);
	}

	@Transactional
	public void removeReservation(Integer tno) {
		// TODO Auto-generated method stub
		Reservation reservTemp = entityManager.find(Reservation.class, tno);
		entityManager.remove(reservTemp);
	}

	
	@Transactional
	public Set<Reservation> cancelledTicketSearch() {

		Set<Reservation> ctSet;
        Query query = entityManager.createQuery("Select br from Reservation br where br.ticketStatus='CANCELLED'");
        
        ctSet = new HashSet(query.getResultList());
        return ctSet;
	}
	

	@Transactional
	public Set<Reservation> reservationChartByRouteNumber(Integer rno) {

		Set<Reservation> ctSet;
        Query query = entityManager.createQuery("Select rs from Reservation rs where rs.route=rno ");
       // String sql="select * from reservation rs where rs.routenumber=(select routenumber from busroute br where br.routenumber='rno'";
      //  Query query=entityManager.createNativeQuery(sql);
        ctSet = new HashSet(query.getResultList());
        return ctSet;
	}
	
	@Transactional 
	public void cancellationTicketByTicketNumber(Integer tno) {
	// TODO Auto-generated method stub
	Reservation r = entityManager.find(Reservation.class, tno);
	if(r!=null)
	{
	Query query = entityManager.createQuery("update reservation br set br.ticketstatus='CANCELLED' where br.ticketnumber="+tno+"");
	int c=query.executeUpdate();
	System.out.println(c);
	}
	else
	System.out.println(r);
}

}
