package com.airbus.repos;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.airbus.pojos.Registration;




@Repository
public class RegistrationRepositoryImpl implements RegistrationRepository {
	
	@PersistenceContext 
	EntityManager entityManager;
	@Transactional
	public void addRegistration(Registration reg) {
		// TODO Auto-generated method stub
		entityManager.persist(reg);
	}

	@Transactional
	public Registration findRegistration(String email) {
		// TODO Auto-generated method stub
		return entityManager.find(Registration.class, email);
	}

	@Transactional
	public Set<Registration> findRegistrations() {
		Set<Registration> regSet;
        Query query = entityManager.createQuery("from Registration");
        
        regSet = new HashSet(query.getResultList());
   
         return regSet;
    }

	@Transactional
	public void modifyRegistration(Registration reg) {
		// TODO Auto-generated method stub
		entityManager.merge(reg);
	}

	@Transactional
	public void removeRegistration(String email) {
		// TODO Auto-generated method stub
		Registration regTemp= entityManager.find(Registration.class, email);
		entityManager.remove(regTemp);
	}

}
