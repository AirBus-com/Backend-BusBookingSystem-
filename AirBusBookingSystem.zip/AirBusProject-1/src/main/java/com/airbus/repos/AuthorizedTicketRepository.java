package com.airbus.repos;


import java.util.Set;

import org.springframework.stereotype.Repository;

import com.airbus.pojos.AuthorizedTicket;

@Repository
public interface AuthorizedTicketRepository {
	
	void addAuthorizedTicket(AuthorizedTicket aRef);
	AuthorizedTicket findAuthorizedTicket(Integer id);
	Set<AuthorizedTicket> findAuthorizedTickets();
	void modifyAuthorizedTicket(AuthorizedTicket aRef);
	void removeAuthorizedTicket(Integer id);
}