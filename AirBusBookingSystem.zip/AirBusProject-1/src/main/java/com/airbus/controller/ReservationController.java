package com.airbus.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.airbus.dtos.ReservationDto;
import com.airbus.pojos.Reservation;
import com.airbus.service.ReservationService;
import com.airbus.service.exception.TicketNumberAlreadyExistsException;
import com.airbus.service.exception.TicketNumberNotFoundException;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ReservationController {

	@Autowired
	ReservationService reServ;
	
	@GetMapping(path="/getReservation/{mytno}")
	@ResponseBody
	public ResponseEntity<Reservation> getReservation(@PathVariable("mytno") Integer tno) throws TicketNumberNotFoundException {
		Reservation re = reServ.findReservationService(tno);
			Reservation resv =null;
			resv = reServ.findReservationService(tno);
			if(resv==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(re);
			}
			
	}
	
	@GetMapping(path="/getReservations")
	@ResponseBody
	public Set<Reservation> getAllReservations() {
		Set<Reservation> reSet = reServ.findReservationsService();
		return reSet;
		
	}
	
	@PostMapping(path="/addReservation")
	public String addReservation(@RequestBody ReservationDto re) {

		try {
			reServ.addReservationService(re);
		} catch (TicketNumberAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Reservation Added Successfully";
		
	}
	
	@PutMapping(path="/modifyReservation")
	public String modifyReservation(@RequestBody Reservation re)throws TicketNumberNotFoundException {
		 String stmsg = null; 
		try {
			 stmsg=reServ.modifyReservationService(re);
		} catch (TicketNumberNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Reservation modify Successfully";
		
	}
	
	@DeleteMapping(path="/deleteReservation/{mytno}")
	@ResponseBody
	public String deleteReservation(@PathVariable("mytno")Integer tno) throws TicketNumberNotFoundException {
		 String stmsg = null; 
		try {
			stmsg=reServ.removeReservationService(tno);
		} catch (TicketNumberNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return stmsg;
		
	}
	
	@GetMapping(path="/cancelledReservations")
	@ResponseBody
	public Set<Reservation> getAllCancelledTickets() throws TicketNumberAlreadyExistsException {
			Set<Reservation> reSet;
			reSet = reServ.cancelledTicketsService();
			return reSet;
	}
	


	
//	@PutMapping(path="/modifyDept")
//	public String modifyDepartment(@RequestBody Department5 dept)throws DepartmentNotFoundException {
//		System.out.println("Department Controller....Understanding client and talking to service layer...");
//		 String stmsg = null;
//		try {
//			stmsg = deptServ.modifyDepartmentService(dept);
//		} 
//		catch (DepartmentNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			return e.getMessage();
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		  return stmsg;
//		
//	}

	
}