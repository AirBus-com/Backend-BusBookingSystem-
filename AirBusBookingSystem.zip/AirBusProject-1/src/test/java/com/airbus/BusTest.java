package com.airbus;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.Bus;
import com.airbus.repos.BusRepository;


@SpringBootTest
class BusTest {
	@Autowired
	 BusRepository busRepo;
	
	@Test
	void findBus() {
		Bus bRou =busRepo.findBus(701);
	    System.out.println(bRou.getFacility());
	    System.out.println(bRou.getStatus());
	    //System.out.println(bRou.getFacility());
	}

	@Test
	void addBus() {
		Bus busObj1 = new Bus();
		busObj1.setBusNumber(701);
		busObj1.setFacility("A/C");
		busObj1.setStatus("Running");
		busRepo.addBus(busObj1);
	}
	@Test
	void deleteBus() {
		
		busRepo.removeBus(700);
	}
	
	/*@Test
	void test() {
		Bus busObj1 = new Bus();
		busObj1.setBusNumber(987);
		busObj1.setFacility("NON-A/C");
		busObj1.setStatus("NOT");
		busRepo.modifyBus(busObj1);
}*/
}
