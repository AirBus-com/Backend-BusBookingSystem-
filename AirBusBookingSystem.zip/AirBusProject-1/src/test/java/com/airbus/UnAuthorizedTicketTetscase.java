package com.airbus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.airbus.pojos.AuthorizedTicket;
import com.airbus.pojos.UnAuthorizedTicket;
import com.airbus.repos.AuthorizedTicketRepository;
import com.airbus.repos.UnauthorizedTicketRepository;
@SpringBootTest
public class UnAuthorizedTicketTetscase {
   @Autowired
   UnauthorizedTicketRepository UauthRepo;
   
    @Test  
    void findUnAuthTicket() 
    {
    	UnAuthorizedTicket unauth = UauthRepo.findUnauthorizedTicket(2);
    	System.out.println(unauth.getEmail());
    	System.out.println(unauth.getPhone());
    	System.out.println(unauth.getUnAuthId());
    	//System.out.println(unauth.getReservation());
    	System.out.println("-----------------");
    }
}


