package com.airbus;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.Bus;
import com.airbus.pojos.BusRoute;
import com.airbus.pojos.Reservation;
import com.airbus.repos.BusRouteRepository;
import com.airbus.repos.ReservationRepository;



@SpringBootTest
class ReservationTest {

	@Autowired
    ReservationRepository resvRepo;
	@Autowired
	BusRouteRepository busRepo;
	

	@Test
	void reservationChart() {
		System.out.println("Displaying all the reservations of route number 123");
		
		BusRoute bRou =busRepo.findBusRoute(123);
	    System.out.println("Destination "+bRou.getDestination());
	    System.out.println("Source :"+bRou.getSource());
	    System.out.println("Arrival Time :"+bRou.getEndTime());
	    System.out.println("Facility : "+bRou.getFacility());
	   
	    System.out.println("Departure Time"+bRou.getStartTime());
	    
	   System.out.println("Ticket Number :"+bRou.getResvSet());
	    
	    Set<Reservation> resSet=bRou.getResvSet();
	    for(Reservation res:resSet)
	    {
	    	System.out.println("TicketNumber :"+res.getTicketNumber());
	    	System.out.println("BookingDate :"+res.getBookingDate());
	    	System.out.println("JourneyDate :"+res.getJourneyDate());
	    	System.out.println("TicketNumber :"+res.getTransactionId());
	    }    
	    
	}
	
//	@Test
//	void reservationChart()
//	{
//		 Set<Reservation> resSet=resvRepo.reservationChartByRouteNumber(123);
//		 for(Reservation res:resSet)
//		    {
//		    	System.out.println("TicketNumber :"+res.getTicketNumber());
//		    	System.out.println("BookingDate :"+res.getBookingDate());
//		    	System.out.println("JourneyDate :"+res.getJourneyDate());
//		    	System.out.println("TicketNumber :"+res.getTransactionId());
//		    } 
//		 
//	}

	
	@Test
	void findCancelledTickets()
	{
		Set<Reservation> ctList =resvRepo.cancelledTicketSearch();
			System.out.println("SET HAS SOME ELEMENTS");
			for (Reservation ct: ctList) 
			{
			System.out.println("cancelled date :"+ct.getCancellationDate()); 
			System.out.println("seat number"+ct.getSeatNumber());
			System.out.println("refund"+ct.getRefund());    
			System.out.println("transaction id"+ct.getTransactionId());   
			System.out.println("journey date"+ct.getJourneyDate());
			System.out.println("Booking date"+ct.getBookingDate());    
			System.out.println("Ticket Number"+ct.getTicketNumber());
			System.out.println("-----------------");
			}
		}
	
	@Test
	void resevationByTicketNo() {
		
		Reservation resv=resvRepo.findReservation(4);
	    System.out.println(resv.getBookingDate());
	    System.out.println(resv.getJourneyDate());
	    System.out.println(resv.getSeatNumber());
	    System.out.println(resv.getTicketStatus());
	    System.out.println(resv.getTransactionId());
	    System.out.println(resv.getRescheduledDate());
	    System.out.println(resv.getRefund());
	    System.out.println(resv.getCancellationDate());
	   // System.out.println(resv.getRoute());
	}

	@Test	void addReservation() {
		Reservation resvObj = new Reservation();
		
		BusRoute r = busRepo.findBusRoute(123);
		resvObj.setRoute(r);
		System.out.println(r);
		resvObj.setTicketNumber(10);
		resvObj.setBookingDate(LocalDate.of(2021, 05,10));
		resvObj.setJourneyDate(LocalDate.of(2021, 05,15));
		resvObj.setCancellationDate(null);
		resvObj.setRescheduledDate(null);
		resvObj.setRefund(null);
		resvObj.setSeatNumber(20);
		resvObj.setTicketStatus("CONFIRM");
		resvObj.setTransactionId(2575);
		resvRepo.addReservation(resvObj);
	}
	
	
		@Test
		void deleteReservation()
		{
			resvRepo.removeReservation(7);
		}
		@Test
		void findResrvations()
		{
			
		Set<Reservation> rSet=resvRepo.findReservations();
		for(Reservation rs:rSet) {
			System.out.println("BookingDate: "+rs.getBookingDate());
			System.out.println("BookingDate: "+rs.getTicketStatus());
			System.out.println("BookingDate: "+rs.getSeatNumber());
			System.out.println("BookingDate: "+rs.getRoute());
			System.out.println("BookingDate: "+rs.getTransactionId());
			System.out.println("BookingDate: "+rs.getJourneyDate());
			
		}
			
		}
		@Test
		void modifyReservation()
		{
			Reservation resvObj = new Reservation();
			resvObj.setTicketNumber(1);
			resvObj.setBookingDate(LocalDate.of(2021, 05,11));
			resvObj.setJourneyDate(LocalDate.of(2021, 05,12));
			resvObj.setCancellationDate(null);
			resvObj.setRescheduledDate(null);
			resvObj.setTicketStatus("CONFIRM");
			resvObj.setRefund(null);
			resvObj.setSeatNumber(15);
			resvObj.setTransactionId(4961);
			resvRepo.modifyReservation(resvObj);
		}
	
}
