package com.airbus;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.AuthorizedTicket;
import com.airbus.pojos.Registration;
import com.airbus.repos.RegistrationRepository;

@SpringBootTest
class RegistrationTestCase {

	
	@Autowired
    RegistrationRepository RegRepo;
    @Test
    void findRegistration()
    {
    	Registration reg = RegRepo.findRegistration("sha@gmail.com");
    	System.out.println(reg.getFirstName());
    	System.out.println(reg.getMiddleName());
    	System.out.println(reg.getLastName());
    	System.out.println(reg.getGender());
    	System.out.println(reg.getPassword());
    	System.out.println(reg.getPhone());
    	System.out.println("-----------------");
    }
  @Test
    public void addregistration() {
    	Registration regObj = new Registration();
   
    	regObj.setFirstName("Soumya");
    	regObj.setMiddleName("B");
    	regObj.setLastName("bindhu");
    	regObj.setGender("F");
    	regObj.setPhone(9182576128L);
    	regObj.setPassword("Sha*dj");
    	regObj.setEmail("bindhu@gmail.com");
    	
    	RegRepo.addRegistration(regObj);
    	
    }
   @Test
    void modifyRegistration() {
    	Registration regObj1 = new Registration();
    	regObj1.setEmail("sai@gmail.com");
    	regObj1.setFirstName("sai");
    	regObj1.setMiddleName("");
    	regObj1.setLastName("");
    	regObj1.setGender("M");
    	regObj1.setPassword("GDHJ@123");
    	regObj1.setPhone(9182576128L);
    	RegRepo.modifyRegistration(regObj1);
    	 
    	
    }
    @Test
    void removeRegistration()
    {
     RegRepo.removeRegistration("sha@gmail.com");
    	
    }
    
    @Test
    void findRegistrations() {
    	Set<Registration> regSet = RegRepo.findRegistrations();
    	
    	for(Registration reg:regSet) {
    		System.out.println("Email : " + reg.getEmail());
    		System.out.println("FirstName : "+ reg.getFirstName());
    		System.out.println("MiddleName : "+ reg.getMiddleName());
    		System.out.println("LastName : "+ reg.getLastName());
    		System.out.println("Gender: "+ reg.getGender());
    		System.out.println("Password : "+ reg.getPassword());
    		System.out.println("Phone : "+ reg.getPhone());
    		System.out.println("-----------------");
    	}
    	
    	
    	
    }  
}