package com.airbus;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.airbus.pojos.AuthorizedTicket;
import com.airbus.pojos.Registration;
import com.airbus.pojos.Reservation;
import com.airbus.repos.AuthorizedTicketRepository;
import com.airbus.repos.RegistrationRepository;
import com.airbus.repos.ReservationRepository;
@SpringBootTest
 class AuthorizedTicketTest {
	
   @Autowired
   AuthorizedTicketRepository authRepo;
   @Autowired
   ReservationRepository resRepo;
   
   @Autowired
   RegistrationRepository regRepo;
   
    @Test
    void findAuthTicket()
    {
    	AuthorizedTicket auth = authRepo.findAuthorizedTicket(1);
    	System.out.println(auth.getId());
    	//System.out.println(auth.getReservation());
    	System.out.println(auth.getRegistration());
    	System.out.println("-----------------");
    }
    
    @Test
    void findAuthorizedTickets()
	{
		
    	Set<AuthorizedTicket> authSet=authRepo.findAuthorizedTickets();
    	System.out.println("Finding all the authorized ticket");
    	for(AuthorizedTicket authTicket:authSet) {
		System.out.println("Finding all the authorized ticket");
		System.out.println("Authorized Id :"+authTicket.getId());
		
		System.out.println("Registrations :"+authTicket.getRegistration());
		System.out.println("Registrations : "+authTicket.getReservation());
		
	}
	}
		
    
    @Test
    void addAuthTicket()
    {

    	AuthorizedTicket authobj1 = new AuthorizedTicket();
    	authobj1.setId(9);
    	//authobj1.setRegistration(regRepo);
    	Reservation resvObj=resRepo.findReservation(1);
    	authobj1.setReservation(resvObj);
    	
    	Registration regObj=regRepo.findRegistration("sha@gmail.com");
    	authobj1.setRegistration(regObj);
    	
    	
    	authRepo.addAuthorizedTicket(authobj1);
	
    }
    
    @Test
    void deleteAuthTicket()
    {
    	authRepo.removeAuthorizedTicket(1);
    	 
    }
    
//    @Test
//    
//    void modifyAuthTicket()
//    {
//    	AuthorizedTicket authobj1 = new AuthorizedTicket();
//    	authobj1.setId(8);	
//    	authRepo.modifyAuthorizedTicket(authobj1);
//    }
//    
    
    @Test
    
    void TicketStatusForAuth() {
    	AuthorizedTicket auth = authRepo.findAuthorizedTicket(1);
    	System.out.println(auth.getId());
    	//System.out.println(auth.getReservation());
    	System.out.println("-----------------");
    	
    	//Reservation res = auth.getReservation();
    	
    	//System.out.println(res.getTicketStatus());
    	
    }
    
}